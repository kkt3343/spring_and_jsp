import pymysql  # pymysql 임포트

# 전역변수 선언부
conn = None
cur = None

conn = pymysql.connect(host='localhost', user='root', password='root', db='test1', charset='utf8')	# 접속정보
cur = conn.cursor()

def create_table():
    sql1 = '''
    CREATE TABLE IF NOT EXISTS TEAM_RANK(
	team_rank INT,
	team_name VARCHAR(50),
	match_count INT,
	winner_point INT,
	win INT,
	draw INT,
	defeat INT,
	goal INT,
	conceded INT,
	goal_diff INT
	)DEFAULT CHARSET=UTF8
    '''

    sql2 = '''
    CREATE TABLE IF NOT EXISTS team_match(
	team_name VARCHAR(50),
	match_date VARCHAR(50),
	stadium VARCHAR(50),
	result_score VARCHAR(100),
	result_base VARCHAR(10),
	result_game VARCHAR(10)
	)DEFAULT CHARSET=UTF8;
    '''

    cur.execute(sql1)
    conn.commit()

    cur.execute(sql2)
    conn.commit()

    conn.close()
