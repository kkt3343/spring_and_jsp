import create_db
import input_db

import time

from selenium.webdriver import Chrome
import chromedriver_autoinstaller
from selenium.webdriver.chrome.options import Options

from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import requests
import re
import os

import input_db_match

chromedriver_autoinstaller.install('./')

chrome_options = Options()
chrome_options.add_experimental_option("detach", True)

# 종료후 창 꺼지지 않게 유지
driver = Chrome(options=chrome_options)


### 팀순위 갱신 ###
def get_team_rank():
    driver.get("https://sports.news.naver.com/wfootball/record/index?category=epl")

    team_table_xpath = '/html/body/div[2]/div[1]/div/div[5]/table'
    team_table_tmp = driver.find_element(By.XPATH, team_table_xpath).find_element(By.TAG_NAME, "tbody").find_elements(By.TAG_NAME, "tr")

    team_table = [["순위", "팀", "경기수", "승점", "승", "무", "패", "득점", "실점", "득실차"]]

    for i in range(len(team_table_tmp)):
        tmp_text = team_table_tmp[i].text.split("\n")
        if len(tmp_text) == 11:
            tmp_text.pop(1)
        team_table.append(tmp_text)

    # for i in range(len(team_table)):
    #     print(team_table[i])

    return team_table


### 일정 받아오기 ###

'''
일정을 얻어 올 때 시즌 마다 팀이 달라 지기 때문에 값을 얻어와야 한다.
순위에서 값을 얻어와서 읽으려 했는데 각 팀마다 약자를 사용하는 팀 ex 맨체스터 유나이티드 FC -> 맨유 이런식으로
마땅한 규칙이 없기 때문에 리스트에 하드코딩해둔다.
'''
def get_match(team_list):
    # 팀별 경기 일정을 위한 리스트 정리

    # 여기에 담아서 리턴
    output_list = []

    team_schedule = []
    for i in range(len(team_list)):
        tmp = []
        tmp.append(team_list[i])
        team_schedule.append(tmp)

    test = driver.find_element(By.ID, "_monthlyScheduleList").find_elements(By.TAG_NAME,"TR")

    day = ""
    for i in range(len(test)):
        if "경기가 없습니다." in test[i].text:
            day = ""
        else:
            k = test[i].find_elements(By.TAG_NAME, "th")
            if len(k) == 1:
                #날짜 출력용
                day = k[0].text
            s = test[i].find_elements(By.TAG_NAME, "td")
            t = s[1].text.split("\n")
            g = s[0].text

            #print(day, g, t)
            for j in range(len(t)):
                # ['에버턴', '1', '승리팀', '아스널', '0'] 라면 에버턴 리스트와 아스널 리스트만 참조할수 있게 된다.
                if t[j] != '승리팀' and not t[j].isdigit():
                    num = team_list.index(t[j])
                    ttmp = []
                    ttmp.append(day)
                    ttmp.append(g)
                    ttmp.append(t)
                    team_schedule[num].append(ttmp)

    #######################################
    for i in range(len(team_schedule)):
        team_name = ""
        for j in range(len(team_schedule[i])):
            if j == 0:
                team_name = team_schedule[i][0]
                # 팀 이름 출력
                # print(team_name)
            else:
                # # 팀 이름 맨 앞에 넣기
                # team_schedule[i][j].insert(0, team_name)
                #team_schedule[i][j].append(team_name)
                #print(team_schedule[i][j], end=' ')
                key = ""
                if team_name == team_schedule[i][j][2][0]:
                    key = "홈"
                else:
                    key = "원정"

                #print(key, end=' ')
                team_schedule[i][j].append(key)

                match_result = ""
                if len(team_schedule[i][j][2]) == 2:
                    match_result = "경기전"
                    #print("경기전", end=' ')

                elif len(team_schedule[i][j][2]) == 4:
                    match_result = "무승부"
                    #print("무승부", end=' ')

                elif len(team_schedule[i][j][2]) == 5:
                    if key == "홈":
                        if team_schedule[i][j][2][2] == "승리팀":
                            match_result = "승리"
                            #print("승리", end=' ')
                        else:
                            match_result = "패배"
                            #print("패배", end=' ')
                    elif key == "원정":
                        if team_schedule[i][j][2][2] == "승리팀":
                            match_result = "패배"
                            #print("패배", end=' ')
                        else:
                            match_result = "승리"
                            #print("승리", end=' ')

                #경기결과 : 경기전, 승리, 무승부, 패배
                team_schedule[i][j].append(match_result)
                #print(match_result)
                # 팀 이름 맨 앞에 넣기
                team_schedule[i][j].insert(0, team_name)
                #print(team_schedule[i][j], end=' ')
                output_list.append(team_schedule[i][j])
                #print()
        #print()
    #print(len(team_schedule))
    return output_list

def get_all_month_match():
    team_list_pre = ["아스널", "맨시티", "맨유", "토트넘", "뉴캐슬", "풀럼", "리버풀", "브라이튼", "브렌트포드", "첼시", "아스톤 빌라", "팰리스", "노팅엄 포레스트",
                 "레스터", "울버햄튼", "웨스트햄", "리즈", "에버턴", "본머스", "사우샘프턴"]

    team_list_la = ["바르셀로나","레알 마드리드","레알 소시에다드","AT 마드리드","레알 베티스","바예카노","오사수나","아틀레틱","마요르카",
                    "비야레알","지로나","에스파뇰","셀타 비고","세비야","알메리아","카디스","레알 바야돌리드","발렌시아","헤타페","엘체"]

    # 팀별 경기 일정을 위한 리스트 정리
    team_schedule = []
    # for i in range(len(team_list_pre)):
    #     tmp = []
    #     team_schedule.append(tmp)

    #프리미어리그
    driver.get("https://sports.news.naver.com/wfootball/schedule/index")

    #라리가
    #driver.get("https://sports.news.naver.com/wfootball/schedule/index?category=primera")

    month_btn = driver.find_element(By.XPATH, '/html/body/div[4]/div[1]/div/div[3]/div[4]/ul')
    month_btn_length = month_btn.find_elements(By.TAG_NAME, "li")
    for i in range(len(month_btn_length)): #len(month_btn_length)
        if i == 0:
            month_btn_length[i].click()
            #print(month_btn_length[i].text)
            time.sleep(5)
        else:
            month_btn = driver.find_element(By.XPATH, '/html/body/div[4]/div[1]/div/div[3]/div[4]/ul')
            month_btn_length = month_btn.find_elements(By.TAG_NAME, "li")
            month_btn_length[i].click()
            #print(month_btn_length[i].text)
            time.sleep(5)

        #프리미어리그
        k = get_match(team_list_pre)
        # print("-===-")
        # for i in k:
        #     print(i)
        # print()

        team_schedule = team_schedule + k

        # for u in range(len(team_schedule)):
        #     if i == 0:
        #         team_schedule[u] = team_schedule[u] + k[u]
        #     else:
        #         team_schedule[u] = team_schedule[u] + k[u][1:]
        #print(team_schedule)

    # for u in range(len(team_schedule)):
    #     print(team_schedule[u])

        #라리가
        #get_match(team_list_la)
        #print("################################")
    return team_schedule


if __name__ == "__main__":
    create_db.create_table()
    team_table = get_team_rank()
    input_db.insert_team_rank(team_table)
    p = get_all_month_match()
    input_db_match.insert_match(p)
