import pymysql  # pymysql 임포트

# 전역변수 선언부
conn = None
cur = None

sql=""

# 메인 코드
conn = pymysql.connect(host='localhost', user='root', password='root', db='test1', charset='utf8')	# 접속정보
cur = conn.cursor()	# 커서생성

def insert_team_rank(team_table):
    sql = 'TRUNCATE TABLE TEAM_RANK'
    cur.execute(sql)
    conn.commit()
    for i in range(1, len(team_table)):
        sql = f"INSERT INTO TEAM_RANK VALUES({team_table[i][0]},\'{team_table[i][1]}\',{team_table[i][2]},{team_table[i][3]},{team_table[i][4]}," \
              f"{team_table[i][5]},{team_table[i][6]},{team_table[i][7]},{team_table[i][8]},{team_table[i][9]})"
        print(sql)
        cur.execute(sql)
    conn.commit()
    conn.close()


