package hello.hellospring.service;

import java.util.List;
import java.util.Map;

import hello.hellospring.dao.UserDAO;
import hello.hellospring.dto.BoardDTO;
import hello.hellospring.dto.UserDTO;
import hello.hellospring.dto.team_match;
import hello.hellospring.dto.team_rank;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

public interface UserService {
    public abstract List<UserDTO> userList();

    public abstract List<BoardDTO> boardList();

    public abstract void insertBoard(Map<String, Object> param);

    public abstract List<BoardDTO> delBoard_check(Map<String, Object> param);

    public abstract void deleteBoard(Map<String, Object> param);

    // 축구팀 가져오기
    public abstract List<team_rank> team_rank();
    public abstract List<team_match> team_match(Map<String, Object> param);
}