package hello.hellospring.service;

import java.util.List;
import java.util.Map;

import hello.hellospring.dto.BoardDTO;
import hello.hellospring.dto.team_match;
import hello.hellospring.dto.team_rank;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hello.hellospring.dto.UserDTO;
import hello.hellospring.dao.UserDAO;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserDAO dao;

    @Autowired
    UserDAO boardDAO;

    @Autowired
    SqlSessionTemplate session;

    @Override
    public List<UserDTO> userList() {
        return dao.userList(session);
    }

    @Override
    public List<BoardDTO> boardList() {
        return boardDAO.boardList(session);
    }

    @Override
    public void insertBoard(Map<String, Object> param){
        session.insert("UserMapper.boardInsert", param);
    }

    @Override
    public List<BoardDTO> delBoard_check(Map<String, Object> param) {
        return session.selectList("UserMapper.boardList_del", param);
        //return boardDAO.boardList_del(session, param);
    }

    @Override
    public void deleteBoard(Map<String, Object> param){
        session.delete("UserMapper.board_delete", param);
    }

    // 축구팀 가져오기
    @Override
    public List<team_rank> team_rank(){
        return session.selectList("UserMapper.team_rank");
    }

    @Override
    public List<team_match> team_match(Map<String, Object> param){
        return session.selectList("UserMapper.team_match", param);
    }
}