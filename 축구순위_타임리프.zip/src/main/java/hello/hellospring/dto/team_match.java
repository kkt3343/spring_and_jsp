package hello.hellospring.dto;

import org.apache.ibatis.type.Alias;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Alias("team_match")
@Getter
@Setter
@ToString
public class team_match {

    String team_name;
    String match_date;
    String stadium;
    String result_score;
    String result_base;
    String result_game;

    public team_match(){}

    public team_match(String team_name, String match_date, String stadium, String result_score,
                      String result_base, String result_game){
        super();
        this.team_name = team_name;
        this.match_date = match_date;
        this.stadium = stadium;
        this.result_score = result_score;
        this.result_base = result_base;
        this.result_game = result_game;
    }
}
