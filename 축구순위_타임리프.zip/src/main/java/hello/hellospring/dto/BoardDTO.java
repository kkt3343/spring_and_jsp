package hello.hellospring.dto;

import org.apache.ibatis.type.Alias;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Alias("board")
@Getter
@Setter
@ToString
public class BoardDTO {
    int board_num;
    String title;
    String pw;
    String content;
    public BoardDTO(){}
    public BoardDTO(int board_num, String pw){
        super();
        this.board_num = board_num;
        this.pw = pw;
    }

    public BoardDTO(int board_num, String title, String pw, String content){
        super();
        this.board_num = board_num;
        this.title = title;
        this.pw = pw;
        this.content = content;
    }

}
