package hello.hellospring.dto;

import org.apache.ibatis.type.Alias;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Alias("team_rank")
@Getter
@Setter
@ToString
public class team_rank {

    int team_rank;
    String team_name;
    int match_count;
    int winner_point;
    int win;
    int draw;
    int defeat;
    int goal;
    int conceded;
    int goal_diff;

    public team_rank(){}

    public team_rank(int team_rank, String team_name, int match_count, int winner_point, int win,
                     int draw, int defeat, int goal, int conceded, int goal_diff){
        super();
        this.team_rank = team_rank;
        this.team_name = team_name;
        this.match_count = match_count;
        this.winner_point = winner_point;
        this.win = win;
        this.draw = draw;
        this.defeat = defeat;
        this.goal = goal;
        this.conceded = conceded;
        this.goal_diff = goal_diff;
    }
}
