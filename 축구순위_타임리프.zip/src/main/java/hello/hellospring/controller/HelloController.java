package hello.hellospring.controller;

import hello.hellospring.dto.BoardDTO;
import hello.hellospring.dto.UserDTO;
import hello.hellospring.dto.team_match;
import hello.hellospring.dto.team_rank;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.coyote.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.*;
import hello.hellospring.service.UserService;

import org.springframework.jdbc.core.JdbcTemplate;

@Controller
public class HelloController {

    // ResponseBody 형식은 API 형식이다. JSON으로 정보를 전달할것이다.
    @RequestMapping("/2")
    @ResponseBody
    public String test1() {
        return "<h1>JSP in Gradle~TEST - @ResponseBody !!</h1>";
    }

    //@RequestMapping(value="/hello")
    //@GetMapping("hello")
    @RequestMapping(value="/hello")
    public String index(Model model) {
        model.addAttribute("data", "hello!!_dddddoooooㄱㄱㄱㄱ");
        //templates 의 hello 접근합니다.
        return "hello";
    }

    @RequestMapping(value="/hello2")
    public String index2(ModelAndView mv) {
        mv.addObject("data","hello2222");
        //model.addAttribute("data", "hello!!_ddddd");
        return "hello";
    }

    @RequestMapping(value="/login")
    public String login() {
        return "a";
    }

    @Autowired
    UserService service;
    @RequestMapping(value="/send", method = RequestMethod.POST)
    public ModelAndView send(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("b");
        mv.addObject("pid",request.getParameter("id"));
        mv.addObject("ppw",request.getParameter("pw"));

        List<UserDTO> userList = service.userList();

        // String sql = "INSERT INTO user(id, pw) VALUE (?, ?)";
        //Object[] params = {iid, ipw};
        // jdbcTemplate.update(sql, params);

        List<List<String>> myList = new ArrayList<>();
        for(int i=0; i< userList.size(); i++){
            List<String> tmp = new ArrayList<>();
            tmp.add(String.valueOf(userList.get(i).getUser_num()));
            tmp.add(userList.get(i).getId());
            tmp.add(userList.get(i).getPw());
            myList.add(tmp);
        }
        System.out.print(myList.size());
        mv.addObject("test", myList);

        return mv;
    }

    @GetMapping("hello-mvc")
    public String helloMvc(@RequestParam("name") String name, Model model){
        model.addAttribute("name", name);
        return "hello-template";
    }

    @GetMapping("hello-string")
    @ResponseBody
    public String helloString(@RequestParam("name") String name){
        return "<h1>" + "hello" + name + "</h1>";
    }

    // API 방식
    @GetMapping("hello-api")
    @ResponseBody
    public Hello helloApi(@RequestParam("name") String name) {
        Hello hello = new Hello();
        hello.setName(name);
        return hello;
    }
    static class Hello{
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    @RequestMapping(value="/board")
    public ModelAndView board() {
        ModelAndView mv = new ModelAndView("board");

        List<BoardDTO> board = service.boardList();
        List<List<String>> myList = new ArrayList<>();
        for(int i=0; i< board.size(); i++){
            List<String> tmp = new ArrayList<>();
            tmp.add(String.valueOf(board.get(i).getBoard_num()));
            tmp.add(board.get(i).getTitle());
            tmp.add(board.get(i).getPw());
            tmp.add(board.get(i).getContent());
            myList.add(tmp);
        }
        //System.out.print(myList.size());
        mv.addObject("test", myList);

        //System.out.print(board);

        return mv;
    }

    @RequestMapping(value="/board_create")
    public String board_create() {
        return "board_create";
    }

    @RequestMapping(value="/board_delete", method = RequestMethod.POST)
    public String board_delete(HttpServletRequest request) {
        String board_num = request.getParameter("board_num");
        String pw = request.getParameter("pw");

        Map<String, Object> param = new HashMap<>();
        param.put("board_num", board_num);

        List<BoardDTO> test = service.delBoard_check(param);
        //System.out.print(test.get(0).getPw());
        if (pw.equals(test.get(0).getPw())){
            System.out.print("match");
            service.deleteBoard(param);
            //성공했으니 리다이렉트 시킨다.
            return "redirect:/board";
        }else{
            System.out.print("not_match");
        }
        return "board_delete_ok";
    }

    @RequestMapping(value="/board_ok", method = RequestMethod.POST)
    public String board_ok(HttpServletRequest request) {
        String title = request.getParameter("title");
        String pw = request.getParameter("pw");
        String content = request.getParameter("content");

        Map<String, Object> param = new HashMap<>();
        param.put("title", title);
        param.put("pw", pw);
        param.put("content", content);

        service.insertBoard(param);

        return "board_ok";
    }

    // 축구 경기
    @RequestMapping(value="/team_rank")
    public ModelAndView team_rank(HttpServletRequest request) {
        List<team_rank> test = service.team_rank();

//        for(int i=0; i<test.size();i++){
//            System.out.println(test.get(i));
//        }

        List<List<String>> myList = new ArrayList<>();
        for(int i=0; i< test.size(); i++){
            List<String> tmp = new ArrayList<>();
            tmp.add(String.valueOf(test.get(i).getTeam_rank()));
            tmp.add(test.get(i).getTeam_name());
            tmp.add(String.valueOf(test.get(i).getMatch_count()));
            tmp.add(String.valueOf(test.get(i).getWinner_point()));
            tmp.add(String.valueOf(test.get(i).getWin()));
            tmp.add(String.valueOf(test.get(i).getDraw()));
            tmp.add(String.valueOf(test.get(i).getDefeat()));
            tmp.add(String.valueOf(test.get(i).getGoal()));
            tmp.add(String.valueOf(test.get(i).getConceded()));
            tmp.add(String.valueOf(test.get(i).getGoal_diff()));
            myList.add(tmp);
        }

        ModelAndView mv = new ModelAndView("team_rank");
        mv.addObject("team_rank", myList);
        return mv;
    }

    @RequestMapping(value="/team_match", method = RequestMethod.POST)
    public ModelAndView team_match(HttpServletRequest request) {
        String team_name = request.getParameter("team_name");

        Map<String, String> team_name_board = new HashMap<>();
        team_name_board.put("아스널 FC", "아스널");
        team_name_board.put("맨체스터 시티 FC", "맨시티");
        team_name_board.put("맨체스터 유나이티드 FC", "맨유");
        team_name_board.put("토트넘 홋스퍼 FC", "토트넘");
        team_name_board.put("뉴캐슬 유나이티드 FC", "뉴캐슬");
        team_name_board.put("리버풀 FC", "리버풀");
        team_name_board.put("브라이튼 앤 호브 알비온 FC", "브라이튼");
        team_name_board.put("브렌트포드 FC", "브렌트포드");
        team_name_board.put("풀럼 FC", "풀럼");
        team_name_board.put("첼시 FC", "첼시");
        team_name_board.put("아스톤 빌라 FC", "아스톤 빌라");
        team_name_board.put("크리스탈 팰리스 FC", "팰리스");
        team_name_board.put("울버햄튼 원더러스 FC", "울버햄튼");
        team_name_board.put("리즈 유나이티드 FC", "리즈");
        team_name_board.put("에버턴 FC", "에버턴");
        team_name_board.put("노팅엄 포레스트 FC", "노팅엄 포레스트");
        team_name_board.put("레스터 시티 FC", "레스터");
        team_name_board.put("웨스트햄 유나이티드 FC", "웨스트햄");
        team_name_board.put("AFC 본머스", "본머스");
        team_name_board.put("사우샘프턴 FC", "사우샘프턴");

        String obj_name = team_name_board.get(team_name);
        System.out.print(obj_name);

        Map<String, Object> param = new HashMap<>();

        param.put("team_name", obj_name);

        List<team_match> test = service.team_match(param);
        //System.out.print(test);
        List<List<String>> myList = new ArrayList<>();
        for(int i=0; i< test.size(); i++){
            List<String> tmp = new ArrayList<>();
            tmp.add(test.get(i).getTeam_name());
            tmp.add(test.get(i).getMatch_date());
            tmp.add(test.get(i).getStadium());
            tmp.add(test.get(i).getResult_score());
            tmp.add(test.get(i).getResult_base());
            tmp.add(test.get(i).getResult_game());
            myList.add(tmp);
        }

        ModelAndView mv = new ModelAndView("team_match");
        mv.addObject("team_origin_name", team_name);
        mv.addObject("team_match", myList);
        return mv;
    }
}
