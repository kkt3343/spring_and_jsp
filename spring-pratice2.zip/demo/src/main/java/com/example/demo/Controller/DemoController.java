package com.example.demo.Controller;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dto.UserDTO;
import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class DemoController {
    @RequestMapping("/2")
    @ResponseBody
	public String test1() {
		return "<h1>JSP in Gradle~TEST - @ResponseBody !!</h1>";
	}

    @RequestMapping(value="/")
    public String index() {
        
        return "index";
    }

    @RequestMapping(value="/login")
    public String index2() {
        
        return "a";
    }

    @Autowired
    private JdbcTemplate jdbcTemplate;
    @RequestMapping(value="/register", method = RequestMethod.POST)
    public String inserttest(HttpServletRequest request) {
        String iid = request.getParameter("id");
        String ipw = request.getParameter("pw");
        // String sql = "INSERT INTO user(id, pw) VALUE (?, ?)";
        //Object[] params = {iid, ipw};
        // jdbcTemplate.update(sql, params);

        Map<String, Object> param = new HashMap<>(); 
        param.put("iid", iid); 
        param.put("ipw", ipw);

        service.insertValue(param);

        return "c";
    }


    @RequestMapping(value="/show01", method = RequestMethod.POST)
    public ModelAndView index3(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("b");
        mv.addObject("pid",request.getParameter("id"));
        mv.addObject("ppw",request.getParameter("pw"));
        return mv;
    }

    @Autowired
	UserService service;
    @RequestMapping(value="/test01")
    public ModelAndView SelectAllFromUser() {
		ModelAndView mav = new ModelAndView("test");
		List<UserDTO> userList = service.userList();
        
        // for(int i=0; i< userList.size(); i++){
        //     System.out.printf("%s ", userList.get(i).getId());
        // }
        // List<String> s = new ArrayList<>() {
        //     {
        //         add("1");
        //         add("2");
        //         add("3");
        //     }
        // };
        // mav.addObject("s",s);
        List<List<String>> myList = new ArrayList<>();
        for(int i=0; i< userList.size(); i++){
            List<String> tmp = new ArrayList<>();
            tmp.add(String.valueOf(userList.get(i).getUser_num()));
            tmp.add(userList.get(i).getId());
            tmp.add(userList.get(i).getPw());
            myList.add(tmp);
        }
        //System.out.println(myList.size());
        //System.out.println(myList.get(0).get(0));

        mav.addObject("test", myList);
		mav.addObject("listp",userList);
        mav.addObject("listp_length",userList.size());

        //System.out.println(userList);

		return mav;
	}
}