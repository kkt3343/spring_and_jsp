package com.example.demo.service;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.UserDAO;
import com.example.demo.dto.UserDTO;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO dao;
	
	@Autowired
	SqlSessionTemplate session;
	
	@Override
	public List<UserDTO> userList() {
		return dao.userList(session);
	}

	@Override
	public void insertValue(Map<String, Object> param) {
		//session.insert("UserMapper.insertValue", param);
		session.insert("UserMapper.insertValue", param);
		//System.out.println();
		//System.out.println(param.get("iid"));
	}
}
