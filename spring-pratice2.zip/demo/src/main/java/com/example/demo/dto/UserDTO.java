package com.example.demo.dto;

import org.apache.ibatis.type.Alias;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Alias("user")
@Getter
@Setter
@ToString
public class UserDTO {
    int user_num;
	String id;
	String pw;
	
	public UserDTO() {}

	public UserDTO(int user_num, String id, String pw) {
		super();
		this.user_num = user_num;
		this.id = id;
		this.pw = pw;
	}

	public UserDTO(String id, String pw) {
		super();
		this.id = id;
		this.pw = pw;
	}
}
