package com.example.demo.dao;

import java.util.List;
import org.mybatis.spring.SqlSessionTemplate;
import com.example.demo.dto.UserDTO;

public interface UserDAO {
    // 2. userList를 여기에서 쓴다. UserMapper.XXXXX
    public abstract List<UserDTO> userList(SqlSessionTemplate session);
}
