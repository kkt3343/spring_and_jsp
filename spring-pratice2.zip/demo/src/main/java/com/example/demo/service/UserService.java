package com.example.demo.service;

import java.util.List;
import java.util.Map;

import com.example.demo.dto.UserDTO;

public interface UserService {
	public abstract List<UserDTO> userList();

	public abstract void insertValue(Map<String, Object> param);

}