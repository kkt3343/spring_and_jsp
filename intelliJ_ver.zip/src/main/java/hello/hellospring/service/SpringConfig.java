package hello.hellospring.service;

import hello.hellospring.dao.MemberRepository;
import hello.hellospring.dao.MemoryMemberRespository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {
    @Bean
    public MemberService memberService(){
        return new MemberService();
    }

    @Bean
    public MemberRepository memberRepository(){
        return new MemoryMemberRespository();
    }
}
