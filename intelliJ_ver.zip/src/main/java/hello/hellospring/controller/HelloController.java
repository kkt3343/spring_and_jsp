package hello.hellospring.controller;

import hello.hellospring.dto.BoardDTO;
import hello.hellospring.dto.UserDTO;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.*;
import hello.hellospring.service.UserService;

import org.springframework.jdbc.core.JdbcTemplate;

@Controller
public class HelloController {

    // ResponseBody 형식은 API 형식이다. JSON으로 정보를 전달할것이다.
    @RequestMapping("/2")
    @ResponseBody
    public String test1() {
        return "<h1>JSP in Gradle~TEST - @ResponseBody !!</h1>";
    }

    //@RequestMapping(value="/hello")
    //@GetMapping("hello")
    @RequestMapping(value="/hello")
    public String index(Model model) {
        model.addAttribute("data", "hello!!_dddddoooooㄱㄱㄱㄱ");
        //templates 의 hello 접근합니다.
        return "hello";
    }

    @RequestMapping(value="/hello2")
    public String index2(ModelAndView mv) {
        mv.addObject("data","hello2222");
        //model.addAttribute("data", "hello!!_ddddd");
        return "hello";
    }

    @RequestMapping(value="/login")
    public String login() {
        return "a";
    }

    @Autowired
    UserService service;
    @RequestMapping(value="/send", method = RequestMethod.POST)
    public ModelAndView send(HttpServletRequest request) {
        ModelAndView mv = new ModelAndView("b");
        mv.addObject("pid",request.getParameter("id"));
        mv.addObject("ppw",request.getParameter("pw"));

        List<UserDTO> userList = service.userList();

        // String sql = "INSERT INTO user(id, pw) VALUE (?, ?)";
        //Object[] params = {iid, ipw};
        // jdbcTemplate.update(sql, params);

        List<List<String>> myList = new ArrayList<>();
        for(int i=0; i< userList.size(); i++){
            List<String> tmp = new ArrayList<>();
            tmp.add(String.valueOf(userList.get(i).getUser_num()));
            tmp.add(userList.get(i).getId());
            tmp.add(userList.get(i).getPw());
            myList.add(tmp);
        }
        System.out.print(myList.size());
        mv.addObject("test", myList);

        return mv;
    }

    @GetMapping("hello-mvc")
    public String helloMvc(@RequestParam("name") String name, Model model){
        model.addAttribute("name", name);
        return "hello-template";
    }

    @GetMapping("hello-string")
    @ResponseBody
    public String helloString(@RequestParam("name") String name){
        return "<h1>" + "hello" + name + "</h1>";
    }

    // API 방식
    @GetMapping("hello-api")
    @ResponseBody
    public Hello helloApi(@RequestParam("name") String name) {
        Hello hello = new Hello();
        hello.setName(name);
        return hello;
    }
    static class Hello{
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    @RequestMapping(value="/board")
    public ModelAndView board() {
        ModelAndView mv = new ModelAndView("board");

        List<BoardDTO> board = service.boardList();
        List<List<String>> myList = new ArrayList<>();
        for(int i=0; i< board.size(); i++){
            List<String> tmp = new ArrayList<>();
            tmp.add(String.valueOf(board.get(i).getBoard_num()));
            tmp.add(board.get(i).getTitle());
            tmp.add(board.get(i).getPw());
            tmp.add(board.get(i).getContent());
            myList.add(tmp);
        }
        //System.out.print(myList.size());
        mv.addObject("test", myList);

        //System.out.print(board);

        return mv;
    }

    @RequestMapping(value="/board_create")
    public String board_create() {
        return "board_create";
    }

    @RequestMapping(value="/board_delete", method = RequestMethod.POST)
    public String board_delete(HttpServletRequest request) {
        String board_num = request.getParameter("board_num");
        String pw = request.getParameter("pw");

        Map<String, Object> param = new HashMap<>();
        param.put("board_num", board_num);

        List<BoardDTO> test = service.delBoard_check(param);
        //System.out.print(test.get(0).getPw());
        if (pw.equals(test.get(0).getPw())){
            System.out.print("match");
            service.deleteBoard(param);
            //성공했으니 리다이렉트 시킨다.
            return "redirect:/board";
        }else{
            System.out.print("not_match");
        }
        return "board_delete_ok";
    }

    @RequestMapping(value="/board_ok", method = RequestMethod.POST)
    public String board_ok(HttpServletRequest request) {
        String title = request.getParameter("title");
        String pw = request.getParameter("pw");
        String content = request.getParameter("content");

        Map<String, Object> param = new HashMap<>();
        param.put("title", title);
        param.put("pw", pw);
        param.put("content", content);

        service.insertBoard(param);

        return "board_ok";
    }

}
