package hello.hellospring.dao;

import java.util.List;
import java.util.Map;

import hello.hellospring.dto.BoardDTO;
import org.mybatis.spring.SqlSessionTemplate;
import hello.hellospring.dto.UserDTO;

public interface UserDAO {
    // 2. userList를 여기에서 쓴다. UserMapper.XXXXX
    public abstract List<UserDTO> userList(SqlSessionTemplate session);

    public abstract List<BoardDTO> boardList(SqlSessionTemplate session);

    public abstract List<BoardDTO> boardList_del(SqlSessionTemplate session, Map<String, Object> param);
}