package hello.hellospring.dao;

import hello.hellospring.dto.Member;

import java.util.List;
import java.util.Optional;

// Repository가 된다.
public interface MemberRepository {
    Member save(Member member);
    Optional<Member> findById(Long id);
    Optional<Member> findMyName(String name);
    List<Member> findAll();
}
