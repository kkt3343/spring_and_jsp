package hello.hellospring.dao;

import java.util.List;
import java.util.Map;

import hello.hellospring.dto.BoardDTO;
import hello.hellospring.dto.UserDTO;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserDAOImpl implements UserDAO{
    // 2. userList를 여기에서 쓴다. UserMapper.XXXXX
    @Override
    public List<UserDTO> userList(SqlSessionTemplate session) {
        return session.selectList("UserMapper.userList");
    }

    @Override
    public List<BoardDTO> boardList(SqlSessionTemplate session) {

        return session.selectList("UserMapper.boardList");
    }

    @Override
    public List<BoardDTO> boardList_del(SqlSessionTemplate session, Map<String, Object> param) {
        return session.selectList("UserMapper.boardList_del", param);
    }
}
